export default function handler(req, res) {
    const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    console.log(`IP capturado: ${ip}`);
    res.status(200).send(`<h1>Seu IP foi registrado: ${ip}</h1>`);
  }
  